#!/bin/bash
#1.定义mysql数据库连接，目标库等信息
MY_USER="back"
MY_PASSWORD="back@xunnuo@huawei.com"
MY_HOST="192.168.16.206"
MY_CONN="-u $MY_USER -p$MY_PASSWORD -h $MY_HOST"
MY_DB="jira"
#2.定义备份目录，时间，文件名
BF_DIR="/backup/jira/sql/"
BF_CMD="/usr/bin/mysqldump"
BF_TIME=`date +%Y%m%d-%H%M%S`
NAME="$MY_DB$BF_TIME"
#3.备份数据，并压缩，删除源文件
cd $BF_DIR
$BF_CMD $MY_CONN $MY_DB> $NAME.sql
/bin/tar zcf $NAME.tar.gz $NAME.sql --remove &> /dev/null
find $BF_DIR -mtime +30 -name "*.*" -exec rm -rf {} \;

