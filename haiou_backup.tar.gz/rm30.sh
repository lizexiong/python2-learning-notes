find /backup/jira/project/ -mtime +15 -name "*.*" -exec rm -rf {} \;
find /backup/jira/fujian/ -mtime +15 -name "*.*" -exec rm -rf {} \;
