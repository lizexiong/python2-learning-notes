#!/bin/bash
rsync -avzH xwp@115.159.90.86:/backup/data/* /backup/haiou
find /backup/haiou  -mtime +14 -name "*.*" -exec rm -rf {} \;
