svn propset ignore
