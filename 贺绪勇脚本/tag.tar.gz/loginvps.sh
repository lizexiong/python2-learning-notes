#!/bin/bash

ssh -qTfnN -D 1080 fquser@69.90.190.229
