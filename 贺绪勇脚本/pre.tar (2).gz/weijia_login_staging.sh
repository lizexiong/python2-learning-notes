#!/bin/bash

ssh -C -g -p 22123 weijia@222.73.136.65
