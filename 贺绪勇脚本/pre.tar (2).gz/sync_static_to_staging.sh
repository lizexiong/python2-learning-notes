#!/bin/bash

user=$1

pre_server=222.73.136.65

script_name=`basename $0`
function usage() {
	echo "usage:$script_name release_version"
	echo "example:$script_name 20140101"
}

#if [[ ! "$1" =~ ^[0-9]{8}$ ]]; then
#	usage
#	exit -1;
#fi

release_dir=/home/test/release

scp -P 22123 $release_dir/djb-static.zip djb@$pre_server:~/release/current/djb-static.zip
#scp -P 22123 $release_dir/djb-static.zip djb@$pre_server:~/release2/current/djb-static.zip
ssh $pre_server  -l $1  '/home/djb/bin/unpack_static.sh'
