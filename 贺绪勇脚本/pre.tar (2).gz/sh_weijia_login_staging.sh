#!/bin/bash

ssh -C -g -p 52113 weijia@222.73.136.33
