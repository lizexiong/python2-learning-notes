#!/bin/bash

url_file=`dirname $0`/djb_url.txt

sed -i 's/\x0D$//' $url_file

while read line
do
echo $line
if [ ! -z $line ]; then
resp=`curl -s -I "$line" | head -n 1`
if [[ "$resp" =~ (200|302) ]]; then
	echo "$line >>>> $resp"
else
	echo -e "\033[0;33;1m$line >>>> $resp \033[0m"
fi
fi
done < $url_file;
