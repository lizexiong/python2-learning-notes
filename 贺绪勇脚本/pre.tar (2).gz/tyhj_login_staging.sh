#!/bin/bash

ssh -C -g -p 22123 tyhj@222.73.136.65
