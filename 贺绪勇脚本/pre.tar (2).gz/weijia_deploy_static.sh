#!/bin/bash

script_dir=`dirname $0`

function usage() {
        echo "usage:deploy_static.sh branch_name"
}

if [ -z "$1" ]; then
	usage;
	exit -1;
fi

local_dir=/home/test/project/static-wj-open
cd $local_dir

if [ "$1" == "trunk" ]; then
	git checkout master	
else
	git checkout $1
fi
git pull

#mkdir release dir
release_dir=/data/djb/static-wj-open
#mkdir -p $release_dir

echo "=============== static-wj-open静态资源发布 =================="
cd /home/test/project/static-wj-open
tar -zcvf static-wj-open.tar.gz *
mv static-wj-open.tar.gz /home/test/release/app/weijia


read -p "是否将应用同步到线上？(y/N)" sure
if [ $sure = 'y' -o $sure = 'Y' ]; then
$script_dir/git_sync_static_to_staging.sh weijia
fi
