#!/bin/bash

prd_server=222.73.136.65

user=$1

script_name=`basename $0`
function usage() {
        echo "usage:$script_name [app_package...]"
        echo "example:$script_name"
}

release_dir=/home/test/release/app

shift

app_packages="$@"
if [ -z $app_packages ]; then
app_packages="."
fi
for app in $app_packages; do
echo rsync -avz --progress '-e ssh -p 22123' $release_dir/$user/$app $user@$prd_server:~/release/current/$release_ver
rsync -avz --progress '-e ssh -p 22123' $release_dir/$user/$app $user@$prd_server:~/release/current/$release_ver
done;
