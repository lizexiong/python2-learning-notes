#!/bin/bash

ssh -C -g -p 22123 fxxt@222.73.136.65
