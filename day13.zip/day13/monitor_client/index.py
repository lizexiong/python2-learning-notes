#!/usr/bin/evn python
#--*-- coding:utf-8 --*--

import time
from plugins import plugins_api



def get_info(rediscli,data,values):

    func = getattr(plugins_api,values['plugin_name'])
    print func()


def run(rediscli,config):
    while True:
        for key,values in config.items():
            data = {'hostname':'222'}
            currenttime, interval, pretime = time.time(),values[interval],values[last_time]
            if currenttime - pretime < interval:
                print "Please Wait..."
            else:
                t = threading.Thread(target=get_info,args=(rediscli,data,values))
                t.start()
                values['last_time']= currenttime




if __name__ == "__main__":
    #每个指标有自己的检测间隔时间
    config = {
        "load:":{"interval" : 6, "last_time" : 0, "plugin_name": "get_load_info"},
        "cpu":{"interval": 6, "last_time": 0, "plugin_name": "get_cpu_info"}
    }
    rediscli = object()
    run(rediscli,config)
