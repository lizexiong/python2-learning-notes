__author__ = 'jieli'

accounts = {
    'alex': {'passwd': "123",
             'quotation': 1000000,
             'home': 'home/alex'
             },
    'jack':{'passwd': "123",
             'quotation': 1000000,
             'home': 'home/jack'
             },
}