#_*_coding:utf-8_*_
__author__ = 'Alex Li'


from modules import users,files
modules = {
    'user' :users.UserModule,
    'file' :files.FileModule
}


