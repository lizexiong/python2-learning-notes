from django.apps import AppConfig


class AryaConfig(AppConfig):
    name = 'Arya'
